#include <stdio.h>

#include "hello1.h"

void hello1(void) {
    printf("hello1");
}

