#pragma once

extern "C" void hello1(void);

